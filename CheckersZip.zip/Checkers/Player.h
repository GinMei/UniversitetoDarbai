﻿#pragma once
#include "GlobalFunctions.h"
#include <bitset>
#include <iostream>
#include <string>
#include <map>
#include <utility>
#include <vector>

using namespace std;
class Player
{
protected:
    bool friendlyPiece;
    wstring piece;
    wstring dame;
    wstring space;
    vector<pair<char, char>> pieceCoordinates;
    vector<pair<char, char>> dameCoordinates;

    bool PieceCaptureCheck(char directionX, char DirectionY, bitset<3> pieceBoard[8][8], pair<char, char> Piece) const
    {
        return (pieceBoard[Piece.first][Piece.second].test(0) &&
            pieceBoard[Piece.first][Piece.second].test(1) == friendlyPiece &&
            pieceBoard[Piece.first + directionX][Piece.second + DirectionY].test(0) &&
            pieceBoard[Piece.first + directionX][Piece.second + DirectionY].test(1) != friendlyPiece &&
            !pieceBoard[Piece.first + 2 * directionX][Piece.second + 2 * DirectionY].test(0));

    }

    bool DameCaptureCheck(char firstBelow, char firstAbove, char secondBelow, char secondAbove, char directionX, char DirectionY, bitset<3> pieceBoard[8][8], pair<char, char> Piece) const
    {
        for (char i = 1; i < 6; i++)
        {
            if (!(Piece.first + i * directionX < firstBelow && Piece.second + i * DirectionY < secondBelow && // out of bounds
                  Piece.first + i * directionX > firstAbove && Piece.second + i * DirectionY > secondAbove) ||
                (pieceBoard[Piece.first + directionX * i][Piece.second + DirectionY * i].test(0) &&
                (pieceBoard[Piece.first + directionX * i][Piece.second + DirectionY * i].test(1) == friendlyPiece || //same color piece in the way
                pieceBoard[Piece.first + directionX * (i + 1)][Piece.second + DirectionY * (i + 1)].test(0)))) //finding 2 pieces in a row
            {
                return false;
            }
            else if (pieceBoard[Piece.first + directionX * i][Piece.second + DirectionY * i].test(0) && //finding something to capture
                    pieceBoard[Piece.first + directionX * i][Piece.second + DirectionY * i].test(1) != friendlyPiece &&
                    !pieceBoard[Piece.first + directionX * (i + 1)][Piece.second + DirectionY * (i + 1)].test(0))//spot after free
            {
                return true;
            }
        }
        return false;
    }

public:
    bool PiecesLeft()
    {
        if (!(pieceCoordinates.empty() && dameCoordinates.empty()))
        {
            return true;
        }
        return false;
    }

    bool CanItMoveThere(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> pieceBoard[8][8])
    {
        if (abs(fromPosition.first - toPosition.first) != abs(fromPosition.second - toPosition.second) ||
            !pieceBoard[fromPosition.first][fromPosition.second].test(0) || // piece isn't there
            pieceBoard[fromPosition.first][fromPosition.second].test(1) != friendlyPiece || // piece is incorrect
            pieceBoard[toPosition.first][toPosition.second].test(0)) // new position is taken
        {
            return false;
        }

        if (!pieceBoard[fromPosition.first][fromPosition.second].test(2) &&
            PieceDirectionCheck(fromPosition, toPosition))
        {
            return true;
        }
        else if (pieceBoard[fromPosition.first][fromPosition.second].test(2)) // piece is dame
        {
            char directionX = (fromPosition.first < toPosition.first) ? 1 : -1;
            char directionY = (fromPosition.second < toPosition.second) ? 1 : -1;
            for (char i = 1; i < abs(toPosition.first - fromPosition.first); i++)
            {
                if (pieceBoard[fromPosition.first + i * directionX][fromPosition.second + i * directionY].test(0))
                {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    virtual bool PieceDirectionCheck(pair<char, char> fromPosition, pair<char, char> toPosition)
    {
        return true;
    }

    pair<char, char> Capture(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> board[8][8])
    {
        char direction1 = fromPosition.first > toPosition.first ? -1 : 1;
        char direction2 = fromPosition.second > toPosition.second ? -1 : 1;
        if (abs(fromPosition.first - toPosition.first) != abs(fromPosition.second - toPosition.second))
        {
            return make_pair(-1, -1);
        }
        if (!board[fromPosition.first][fromPosition.second].test(2))
        {
            if (abs(fromPosition.first - toPosition.first) == 2 && PieceCaptureCheck(direction1, direction2, board, fromPosition))
            {
                return make_pair(fromPosition.first + direction1, fromPosition.second + direction2);
            }
            else
            {
                return make_pair(-1, -1);
            }
        }
        else
        {
            pair<char, char> result = make_pair(-1, -1);

            //for (char i = 1; i < abs(fromPosition.first - toPosition.first) - 1; i++)
            //{
            //    if (board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(0))
            //    {
            //        if (result == make_pair(-1, -1) &&
            //            board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(1) != friendlyPiece)//test 
            //        {
            //            result = make_pair(fromPosition.first + direction1 * i, fromPosition.second + direction2 * i);
            //        }
            //        else
            //        {
            //            return make_pair(-1, -1);
            //        }
            //    }
            //}
            if (board[toPosition.first][toPosition.second].test(0))
            {
                return make_pair(-1, -1);
            }
            for (char i = 1; i < abs(fromPosition.first - toPosition.first); i++)
            {
                if ((board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(0) &&
                    (board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(1) == friendlyPiece || //same color piece in the way
                    board[fromPosition.first + direction1 * (i + 1)][fromPosition.second + direction2 * (i + 1)].test(0))) || // OR 2 pieces in a row
                    (board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(0) && 
                    board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(1) != friendlyPiece &&
                    result != make_pair(-1, -1)))//something in the way after finding what to capture
                {
                    return make_pair(-1, -1);
                }
                else if (board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(0) &&
                        board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i].test(1) != friendlyPiece &&
                        !board[fromPosition.first + direction1 * (i + 1)][fromPosition.second + direction2 * (i + 1)].test(0) &&
                        result == make_pair(-1, -1))//finding something to capture
                {
                    result = make_pair(fromPosition.first + direction1 * i, fromPosition.second + direction2 * i);
                }
            }
            return result;
        }
    }

    void ErasePiece(pair<char, char> position, bool isItPiece)
    {
        GoToBoardCoordinates(position);
        wcout << space;
        if (isItPiece)
        {
            for (char i = 0; i < (char)pieceCoordinates.size(); i++)
            {
                if (pieceCoordinates[i] == position)
                {
                    pieceCoordinates.erase(pieceCoordinates.begin() + i);
                    return;
                }
            }
        }
        else
        {
            for (char i = 0; i < (char)dameCoordinates.size(); i++)
            {
                if (dameCoordinates[i] == position)
                {
                    dameCoordinates.erase(dameCoordinates.begin() + i);
                    return;
                }
            }
        }
    }

    virtual void AddPiece(pair<char, char> position, bool isItPiece) { }

    void MovePiece(pair<char, char> fromPosition, pair<char, char> toPosition, bool isItPiece)
    {
        ErasePiece(fromPosition, isItPiece);
        AddPiece(toPosition, isItPiece);
    }

    void PieceToOutput(pair<char, char> position, bool isItPiece) const
    {
        GoToBoardCoordinates(position);
        if (isItPiece)
        {
            wcout << piece;
        }
        else
        {
            wcout << dame;
        }
    }

    bool CheckForCapture(bitset<3> pieceBoard[8][8])
    {
        for (pair<char, char> Piece : pieceCoordinates)
        {
            if (CheckForSpecifiedCapture(pieceBoard, Piece))
            {
                return true;
            }
        }
        for (pair<char, char> Dame : dameCoordinates)
        {
            if (CheckForSpecifiedCapture(pieceBoard, Dame))
            {
                return true;
            }
        }
        return false;
    }

    bool CheckForSpecifiedCapture(bitset<3> pieceBoard[8][8], pair<char, char> Piece)
    {
        if (!pieceBoard[Piece.first][Piece.second].test(2))
        {
            return ((Piece.first < 6 && Piece.second < 6 && PieceCaptureCheck(+1, +1, pieceBoard, Piece)) ||
                    (Piece.first > 1 && Piece.second > 1 && PieceCaptureCheck(-1, -1, pieceBoard, Piece)) ||
                    (Piece.first > 1 && Piece.second < 6 && PieceCaptureCheck(-1, +1, pieceBoard, Piece)) ||
                    (Piece.first < 6 && Piece.second > 1 && PieceCaptureCheck(+1, -1, pieceBoard, Piece)));
        }
        else
        {
            return  (DameCaptureCheck(6, -1, 6, -1,  +1, +1, pieceBoard, Piece)) ||
                    (DameCaptureCheck(8, +1, 8, +1,  -1, -1, pieceBoard, Piece)) ||
                    (DameCaptureCheck(6, -1, 8, +1,  -1, +1, pieceBoard, Piece)) ||
                    (DameCaptureCheck(8, +1, 6, -1,  +1, -1, pieceBoard, Piece));
        }
    }
};
