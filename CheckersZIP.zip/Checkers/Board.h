﻿#pragma once
#include "BlackPlayer.h"
#include "WhitePlayer.h"
#include "GlobalFunctions.h"
#include <bitset>
#include <iostream>
#include <string>
#include <map>
#include <utility>

using namespace std;
class Board
{
private:
    bitset<3> pieceBoard[8][8]; //[x][y][bit] 0(there) 1(black) 2(dame)
    BlackPlayer blackPlayer;
    WhitePlayer whitePlayer;
    bool blackPlayerTurn;
    bool repeatingCapture;
    pair<char, char> moveFromPosition;

public:
    bool blackTurn() const
    {
        return blackPlayerTurn;
    }

    Board()
    {
        boardDiplay(false);
        blackPlayer = BlackPlayer(false);
        whitePlayer = WhitePlayer(false);
        blackPlayerTurn = true;
        repeatingCapture = false;
    }

    Board(bool colorRed)
    {
        boardDiplay(colorRed);
        blackPlayer = BlackPlayer(colorRed);
        whitePlayer = WhitePlayer(colorRed);
        blackPlayerTurn = true;
        repeatingCapture = false;

        for (char i = 0; i < 3; i++)
        {
            for (char j = 0; j < 8; j++)
            {
                if ((i + j) % 2 == 1)
                {
                    pieceBoard[i][j].set(0);
                    pieceBoard[i][j].set(1);
                    blackPlayer.AddPiece(make_pair(i, j), true);
                }
            }
        }

        for (char i = 5; i < 8; i++)
        {
            for (char j = 0; j < 8; j++)
            {
                if ((i + j) % 2 == 1)
                {
                    pieceBoard[i][j].set(0);
                    whitePlayer.AddPiece(make_pair(i, j), true);
                }
            }
        }
    }

    ~Board() { }

    void boardDiplay(bool colorRed)
    {
        wstring color1;
        wstring color2;
        if (colorRed) //red
        {
            color1 = L"\033[47;31m";
            color2 = L"\033[41;37m";
        }
        else //black
        {
            color1 = L"\033[47;30m";
            color2 = L"\033[0;0m";
        }

        GoTo(0, 0);

        wcout << color1 << L"      a   b   c   d   e   f   g   h              a   b   c   d   e   f   g   h     \n"
            << L"   ▐" << color2 << L"▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖    " << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖    " << color1 << L"▌  \n"
            << L" 8 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 8    8 ▐" << color2 << L"▐███▌ 1 ▐███▌ 2 ▐███▌ 3 ▐███▌ 4  " << color1 << L"▌ 8\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 7 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 7    7 ▐" << color2 << L"  5 ▐███▌ 6 ▐███▌ 7 ▐███▌ 8 ▐███▌" << color1 << L"▌ 7\n"
            << L"   ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌  \n"
            << L" 6 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 6    6 ▐" << color2 << L"▐███▌ 9 ▐███▌1 0▐███▌1 1▐███▌1 2 " << color1 << L"▌ 6\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 5 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 5    5 ▐" << color2 << L" 1 3▐███▌1 4▐███▌1 5▐███▌1 6▐███▌" << color1 << L"▌ 5\n"
            << L"   ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌  \n"
            << L" 4 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 4    4 ▐" << color2 << L"▐███▌1 7▐███▌1 8▐███▌1 9▐███▌2 0 " << color1 << L"▌ 4\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 3 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 3    3 ▐" << color2 << L" 2 1▐███▌2 2▐███▌2 3▐███▌2 4▐███▌" << color1 << L"▌ 3\n"
            << L"   ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌  \n"
            << L" 2 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 2    2 ▐" << color2 << L"▐███▌2 5▐███▌2 6▐███▌2 7▐███▌2 8 " << color1 << L"▌ 2\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 1 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 1    1 ▐" << color2 << L" 2 9▐███▌3 0▐███▌3 1▐███▌3 2▐███▌" << color1 << L"▌ 1\n"
            << L"   ▐" << color2 << L"    ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"    ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘" << color1 << L"▌  \n"
            << L"      a   b   c   d   e   f   g   h              a   b   c   d   e   f   g   h     \033[0;0m" << endl;
    }

    bool IsGameOngoing()
    {
        if (whitePlayer.PiecesLeft() && blackPlayer.PiecesLeft())
        {
            return true;
        }
        return false;
    }

    void MakeMove(pair<char, char> fromPosition, pair<char, char> toPosition)
    {
        if (blackPlayerTurn)
        {
            if (((repeatingCapture && moveFromPosition == fromPosition) || !repeatingCapture) && blackPlayer.CheckForCapture(pieceBoard))
            {
                pair<char, char> capturedPiece = blackPlayer.Capture(fromPosition, toPosition, pieceBoard);
                if (capturedPiece != make_pair(-1, -1))
                {
                    blackPlayer.BoardMovement(pieceBoard, fromPosition, toPosition);
                    whitePlayer.ErasePiece(capturedPiece, pieceBoard[capturedPiece.first][capturedPiece.second].test(2));
                    pieceBoard[capturedPiece.first][capturedPiece.second].reset(0);
                    pieceBoard[capturedPiece.first][capturedPiece.second].reset(1);
                    pieceBoard[capturedPiece.first][capturedPiece.second].reset(2);

                    if (!blackPlayer.CheckForSpecifiedCapture(pieceBoard, toPosition))
                    {
                        Error("Turn is over"); 
                        repeatingCapture = false;
                        blackPlayerTurn = false;
                    }
                    else
                    {
                        moveFromPosition = toPosition;
                        repeatingCapture = true;
                    }
                }
                else
                {
                    Error("You have to capture!");
                }

            }
            else if (blackPlayer.CanItMoveThere(fromPosition, toPosition, pieceBoard)) // correct move
            {
                blackPlayer.BoardMovement(pieceBoard, fromPosition, toPosition);
                Error("Turn is over");
                blackPlayerTurn = false;
            }
            else
            {
                Error("Illegal move!");
            }
        }
        else //White Player's move
        {
            if (((repeatingCapture && moveFromPosition == fromPosition) || !repeatingCapture) && whitePlayer.CheckForCapture(pieceBoard))
            {
                auto capturedPiece = whitePlayer.Capture(fromPosition, toPosition, pieceBoard);
                if (capturedPiece != make_pair(-1, -1))
                {
                    whitePlayer.BoardMovement(pieceBoard, fromPosition, toPosition);
                    GoToBoardCoordinates(capturedPiece);
                    blackPlayer.ErasePiece(capturedPiece, pieceBoard[capturedPiece.first][capturedPiece.second].test(2));
                    pieceBoard[capturedPiece.first][capturedPiece.second].reset(0);
                    pieceBoard[capturedPiece.first][capturedPiece.second].reset(1);
                    pieceBoard[capturedPiece.first][capturedPiece.second].reset(2);

                    if (!whitePlayer.CheckForSpecifiedCapture(pieceBoard, toPosition))
                    {
                        Error("Turn is over");
                        blackPlayerTurn = true;
                        repeatingCapture = false;
                    }
                    else
                    {
                        moveFromPosition = toPosition;
                        repeatingCapture = true;
                    }
                }
                else
                {
                    Error("You have to capture!");
                }
            }
            else if (whitePlayer.CanItMoveThere(fromPosition, toPosition, pieceBoard)) // correct move
            {
                whitePlayer.BoardMovement(pieceBoard, fromPosition, toPosition);
                Error("Turn is over");
                blackPlayerTurn = true;
            }
            else
            {
                Error("Illegal move!");
            }
        }
    }
};
