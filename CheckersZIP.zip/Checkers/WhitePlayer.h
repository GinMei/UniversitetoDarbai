﻿#pragma once
#include "Player.h"
#include "GlobalFunctions.h"
#include <bitset>
#include <iostream>
#include <string>
#include <map>
#include <utility>
#include <vector>

using namespace std;
class WhitePlayer : public Player
{
private:
    bool PieceDirectionCheck(pair<char, char> fromPosition, pair<char, char> toPosition) override
    {
        return (fromPosition.first - 1 == toPosition.first);
    }

public:
    WhitePlayer() { }
    WhitePlayer(bool colorRed)
    {
        friendlyPiece = false;
        if (colorRed) //if white/red board
        {
            piece = L"\033[41;37m●\033[0;0m";
            dame = L"\033[41;37m◯\033[0;0m";
            space = L"\033[41;37m \033[0;0m";
        }
        else //white/black board
        {
            piece = L"\033[0;37m●\033[0;0m";
            dame = L"\033[0;37m◯\033[0;0m";
            space = L"\033[0;37m \033[0;0m";
        }
    }

    void AddPiece(pair<char, char> position, bool isItPiece) override
    {
        if ((position.first + position.second) % 2 == 1)
        {
            if (!isItPiece || position.first == 0)
            {
                dameCoordinates.push_back(position);
            }
            else
            {
                pieceCoordinates.push_back(position);
            }
        }
        PieceToOutput(position, (isItPiece && position.first != 0));
    }

    void BoardMovement(bitset<3> pieceBoard[8][8], pair<char, char> fromPosition, pair<char, char> toPosition)
    {
        MovePiece(fromPosition, toPosition, !pieceBoard[fromPosition.first][fromPosition.second].test(2));
        pieceBoard[toPosition.first][toPosition.second] = pieceBoard[fromPosition.first][fromPosition.second];

        if (toPosition.first == 0)
        {
            pieceBoard[toPosition.first][toPosition.second].set(2);
        }
        pieceBoard[fromPosition.first][fromPosition.second].reset();
    }
};
