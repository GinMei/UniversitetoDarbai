﻿#include <bitset>
#include <iostream>
#include <string>
#include <map>
#include <utility>
#include <io.h>
#include <fcntl.h>
#include <Windows.h>
#include <vector>
#include <thread>
#include <chrono>
#include "Board.h"
#include "GlobalFunctions.h"

using namespace std;
int main()
{
    SetConsoleOutputCP(CP_UTF8);
    std::wcout.imbue(std::locale("en_US.UTF-8"));

    Board board(false);
    pair<char, char> fromPosition, ToPosition;
    while (board.IsGameOngoing())
    {
        GoTo(20, 0);
        wcout << L"Please enter the position of the piece you'd like to move and\nthe position of where you'd like to move it, in format 08-12\n";
        while (1)
        {
            playersMove(board.blackTurn(), fromPosition, ToPosition);
            board.MakeMove(fromPosition, ToPosition);
        }
    }
    GoTo(24, 0);
        cout << "█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\n"
            << "█     ▚  ▞ ▌ ▛▀ ▀▜▀ ▐▀▀▌ ▐▛▜     █\n"
            << "█      ▚▞  ▌ ▙▄  ▐  ▐▄▄▌ ▐▛▚     █\n"
            << "█                                █\n";
    if (board.blackTurn())
    {
        cout << "█             BLACK              █\n";
    }
    else
    {
        cout << "█             WHITE              █\n";
    }
            cout << "█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█";
            GoTo(30, 0);
    return 0;
}
/*
TODO
fix capture from first row?
*/