﻿#pragma once
#include "Player.h"
#include "GlobalFunctions.h"

using namespace std;
class WhitePlayer : public Player
{
private:
    bool PieceDirectionCheck(pair<char, char> fromPosition, pair<char, char> toPosition) override
    {
        return (fromPosition.first - 1 == toPosition.first);
    }
public:
    WhitePlayer() { }

    WhitePlayer(bool colorRed)
    {
        friendlyPiece = false;
        if (colorRed)
        {
            piece = L"\033[41;37m●\033[0;0m";
            dame = L"\033[41;37m◯\033[0;0m";
            space = L"\033[41;37m \033[0;0m";
        }
        else
        {
            piece = L"\033[0;37m●\033[0;0m";
            dame = L"\033[0;37m◯\033[0;0m";
            space = L"\033[0;37m \033[0;0m";
        }
    }

    void AddPiece(pair<char, char> position, bool isItDame, bitset<3>& piece) override
    {
        if ((position.first + position.second) % 2 == 1)
        {
            piece.set(0);
            if (isItDame || position.first == 0)
            {
                piece.set(2);
                dameCoordinates.push_back(position);
            }
            else
            {
                pieceCoordinates.push_back(position);
            }
        }
        PieceToOutput(position, (!isItDame && position.first != 0));
    }
};
