﻿#pragma once
#include "BlackPlayer.h"
#include "WhitePlayer.h"
#include "GlobalFunctions.h"

using namespace std;
const char boardSize = 8;

class Board
{
private:
    bitset<3> pieceBoard[8][8]; //[x][y][bit] 0(there) 1(black) 2(dame)
    BlackPlayer blackPlayer;
    WhitePlayer whitePlayer;
    bool blackPlayerTurn;
    bool repeatingCapture;
    pair<char, char> moveFromPosition;

public:
    bool blackTurn() const
    {
        return blackPlayerTurn;
    }

    Board()
    {
        boardDiplay(false);
        blackPlayer = BlackPlayer(false);
        whitePlayer = WhitePlayer(false);
        blackPlayerTurn = true;
        repeatingCapture = false;
    }

    Board(bool colorRed)
    {
        boardDiplay(colorRed);
        blackPlayer = BlackPlayer(colorRed);
        whitePlayer = WhitePlayer(colorRed);
        blackPlayerTurn = true;
        repeatingCapture = false;

        for (char i = 0; i < 3; i++)
        {
            FillLine(i, true, blackPlayer);
        }

        for (char i = boardSize-3; i < boardSize; i++)
        {
            FillLine(i, false, whitePlayer);
        }
    }

    ~Board() { }

    void boardDiplay(bool colorRed)
    {
        wstring color1 = L"\033[47;30m";
        wstring color2 = L"\033[0;0m";
        if (colorRed) //red
        {
            color1 = L"\033[47;31m";
            color2 = L"\033[41;37m";
        }
        GoTo(0, 0);
        wcout << color1 << L"      a   b   c   d   e   f   g   h              a   b   c   d   e   f   g   h     \n"
            << L"   ▐" << color2 << L"▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖    " << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖   ▗▄▄▄▖    " << color1 << L"▌  \n"
            << L" 8 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 8    8 ▐" << color2 << L"▐███▌ 1 ▐███▌ 2 ▐███▌ 3 ▐███▌ 4  " << color1 << L"▌ 8\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 7 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 7    7 ▐" << color2 << L"  5 ▐███▌ 6 ▐███▌ 7 ▐███▌ 8 ▐███▌" << color1 << L"▌ 7\n"
            << L"   ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌  \n"
            << L" 6 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 6    6 ▐" << color2 << L"▐███▌ 9 ▐███▌1 0▐███▌1 1▐███▌1 2 " << color1 << L"▌ 6\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 5 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 5    5 ▐" << color2 << L" 1 3▐███▌1 4▐███▌1 5▐███▌1 6▐███▌" << color1 << L"▌ 5\n"
            << L"   ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌  \n"
            << L" 4 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 4    4 ▐" << color2 << L"▐███▌1 7▐███▌1 8▐███▌1 9▐███▌2 0 " << color1 << L"▌ 4\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 3 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 3    3 ▐" << color2 << L" 2 1▐███▌2 2▐███▌2 3▐███▌2 4▐███▌" << color1 << L"▌ 3\n"
            << L"   ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"▗▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▘" << color1 << L"▌  \n"
            << L" 2 ▐" << color2 << L"▐███▌   ▐███▌   ▐███▌   ▐███▌    " << color1 << L"▌ 2    2 ▐" << color2 << L"▐███▌2 5▐███▌2 6▐███▌2 7▐███▌2 8 " << color1 << L"▌ 2\n"
            << L"   ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌        ▐" << color2 << L"▝▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▞▀▀▀▚▄▄▄▖" << color1 << L"▌  \n"
            << L" 1 ▐" << color2 << L"    ▐███▌   ▐███▌   ▐███▌   ▐███▌" << color1 << L"▌ 1    1 ▐" << color2 << L" 2 9▐███▌3 0▐███▌3 1▐███▌3 2▐███▌" << color1 << L"▌ 1\n"
            << L"   ▐" << color2 << L"    ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘" << color1 << L"▌        ▐" << color2 << L"    ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘   ▝▀▀▀▘" << color1 << L"▌  \n"
            << L"      a   b   c   d   e   f   g   h              a   b   c   d   e   f   g   h     \033[0;0m" << endl;
    }

    template <typename T>
    void FillLine(char i, bool black, T& player)
    {
        for (char j = 0; j < boardSize; j++)
        {
            if ((i + j) % 2 == 1)
            {
                player.AddPiece(make_pair(i, j), false, pieceBoard[i][j]);
            }
        }
    }

    bool IsGameOngoing()
    {
        return (whitePlayer.PiecesLeft() && blackPlayer.PiecesLeft());
    }

    void MakeMove(pair<char, char> fromPosition, pair<char, char> toPosition)
    {
        if (blackPlayerTurn)
        {
            PlayerMove(fromPosition, toPosition, blackPlayer, whitePlayer);
        }
        else
        {
            PlayerMove(fromPosition, toPosition, whitePlayer, blackPlayer);
        }
    }

    template <typename T1, typename T2>
    void PlayerMove(pair<char, char> fromPosition, pair<char, char> toPosition, T1& playerToMove, T2& otherPlayer)
    {
        if (playerToMove.CheckForCapture(pieceBoard))
        {
            CaptureMove(fromPosition, toPosition, playerToMove, otherPlayer);
        }
        else if (playerToMove.CanItMoveThere(fromPosition, toPosition, pieceBoard))
        {
            playerToMove.MovePiece(fromPosition, toPosition, pieceBoard);
            blackPlayerTurn = !blackPlayerTurn;
            Error("Turn is over");
        }
        else
        {
            Error("Illegal move!");
        }
    }

    template <typename T1, typename T2>
    void CaptureMove(pair<char, char> fromPosition, pair<char, char> toPosition, T1& playerToMove, T2& otherPlayer)
    {
        pair<char, char> capturedPiece = playerToMove.Capture(fromPosition, toPosition, pieceBoard);
        if (((repeatingCapture && moveFromPosition == fromPosition) || !repeatingCapture) && capturedPiece != invalidMove)
        {
            playerToMove.MovePiece(fromPosition, toPosition, pieceBoard);
            otherPlayer.ErasePiece(capturedPiece, pieceBoard[capturedPiece.first][capturedPiece.second]);

            if (!playerToMove.CheckForSpecifiedCapture(pieceBoard, toPosition))
            {
                Error("Turn is over");
                repeatingCapture = false;
                moveFromPosition = invalidMove;
                blackPlayerTurn = !blackPlayerTurn;
            }
            else
            {
                moveFromPosition = toPosition;
                repeatingCapture = true;
            }
        }
        else
        {
            Error("You have to capture!");
        }
    }
};
