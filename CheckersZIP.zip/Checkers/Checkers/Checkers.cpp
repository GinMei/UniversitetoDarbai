﻿#include "BoardSingleton.h"
#include "Board.h"
#include "GlobalFunctions.h"

using namespace std;
BoardSingleton* BoardSingleton::instance = nullptr;

int main()
{
    SetConsoleOutputCP(CP_UTF8);
    std::wcout.imbue(std::locale("en_US.UTF-8"));

    BoardSingleton& game = BoardSingleton::getInstance();

    game.Play(false);

    return 0;
}
/*
09-14
22-18
10-15
18-09
05-14
21-17
14-21
26-22
06-10
30-26
21-30
23-19
30-23
23-16
24-19
16-23
27-18
01-05
18-14
10-17
17-26
31-22
12-16
22-18
15-22
29-25
22-29
28-24
16-20
32-27
11-16
27-23
20-27
27-18
*/