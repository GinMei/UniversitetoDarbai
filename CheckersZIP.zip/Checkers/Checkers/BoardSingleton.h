﻿#pragma once
#include "GlobalFunctions.h"
#include "Board.h"
using namespace std;
class BoardSingleton {
private:
    BoardSingleton() { }

    ~BoardSingleton() { }

    static BoardSingleton* instance;
    Board board;
public:
    static BoardSingleton& getInstance()
    {
        if (!instance) {
            instance = new BoardSingleton();
        }
        return *instance;
    }
    
    void Play(bool value)
    {
        board = Board(value);
        pair<char, char> fromPosition, ToPosition;
        while (board.IsGameOngoing())
        {
            GoTo(20, 0);
            wcout << L"Please enter the position of the piece you'd like to move and\nthe position of where you'd like to move it, in format 08-12\n";
            playersMove(board.blackTurn(), fromPosition, ToPosition);
            board.MakeMove(fromPosition, ToPosition);
        }
        DisplayVictor(board.blackTurn());
    }

    BoardSingleton(const BoardSingleton&) = delete;
    BoardSingleton& operator = (const BoardSingleton&) = delete;
};

