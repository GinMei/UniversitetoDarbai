﻿#include "GlobalFunctions.h"

void Wait(char seconds) {
    this_thread::sleep_for(chrono::seconds(seconds));
}

void GoTo(short line, short column) {
    line += boardPosition;
    wcout << L"\x1b[" << line << ";" << column << "H";
}

void Error(string text) {
    GoTo(23, 0);
    cout << del_line << "\033[0;31m" << text << "\033[0;0m";
    Wait(2);
    ClearLines(1);
}

void Comment(string text) {
    GoTo(22, 0);
    cout << del_line << "\033[35m" << text << "\033[0;0m";
}

void ClearLines(short amount) {
    for (short i = 0; i < amount; i++) {
        cout << del_line << prev_line;
    }
    cout << del_line;
}

void playersMove(bool blackMove, pair<char, char>& fromPosition, pair<char, char>& ToPosition) {
    string input;
    if (blackMove) {
        Comment("Black's move: ");
    }
    else {
        Comment("White's move: ");
    }

    while (1) {
        getline(cin, input);
        ClearLines(1);
        if (!input.empty()) break;
    }

    if (GetMoveInput(input)) {
        GoTo(23, 0);
        ClearLines(1);
        fromPosition = NumToCoordinates(stoi(input.substr(0, 2)));
        ToPosition = NumToCoordinates(stoi(input.substr(3, 2)));
        return;
    }
    else {
        GoTo(22, 0);
    }
}

void DisplayVictor(bool victor)
{
    GoTo(24, 0);
    cout << "█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\n"
        << "█     ▚  ▞ ▌ ▛▀ ▀▜▀ ▐▀▀▌ ▐▛▜     █\n"
        << "█      ▚▞  ▌ ▙▄  ▐  ▐▄▄▌ ▐▛▚     █\n"
        << "█                                █\n";
    if (victor)
    {
        cout << "█             BLACK              █\n";
    }
    else
    {
        cout << "█             WHITE              █\n";
    }
    cout << "█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█";
    GoTo(30, 0);
}

void GoToBoardCoordinates(pair<char, char> position) {
    GoTo((2 + position.first * 2), (7 + position.second * 4));
}

bool GetMoveInput(string& input) {
    char number1 = 0, number2 = 0;
    try {
        if (input.length() != 5 || input[2] != '-') {
            throw (exception)"OutOfBounds";
        }
        number1 = stoi(input.substr(0, 2));
        number2 = stoi(input.substr(3, 2));
        if (number1 < 1 || number1 > 32 || number2 < 1 || number2 > 32) {
            throw (exception)"OutOfBounds";
        }
    }
    catch (exception a) {
        Error("Wrong input!");
        return false;
    }
    return true;
}

pair<char, char> NumToCoordinates(char number) {
    number--;
    char X = (char)floor(number / 4.0);
    char Y = (number % 4) * 2;

    if (X % 2 == 0) {
        Y++;
    }
    return make_pair(X, Y);
}