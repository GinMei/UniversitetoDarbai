﻿#pragma once
#include "GlobalFunctions.h"
#include "PlayerBase.h"

using namespace std;
const char lastBoardIndex = 7;
const pair<char, char> invalidMove = make_pair(-1,-1);

class Player : public PlayerBase
{
protected:
    bool PieceCaptureCheck(char directionX, char DirectionY, bitset<3> pieceBoard[8][8], pair<char, char> Piece) const
    {
        bitset<3> from = pieceBoard[Piece.first][Piece.second],
            capture = pieceBoard[Piece.first + directionX][Piece.second + DirectionY];

        return (from.test(0) && from.test(1) == friendlyPiece && capture.test(0) && capture.test(1) != friendlyPiece &&
                !pieceBoard[Piece.first + 2 * directionX][Piece.second + 2 * DirectionY].test(0));
    }

    bool DameCaptureCheck(char directionX, char DirectionY, bitset<3> pieceBoard[8][8], pair<char, char> Piece) const
    {
        char coord1, coord2;
        for (char i = 1; i < lastBoardIndex; i++)
        {
            coord1 = Piece.first + i * directionX;
            coord2 = Piece.second + i * DirectionY;

            if (!(coord1 < lastBoardIndex && coord2 < lastBoardIndex && coord1 > 0 && coord2 > 0) ||
                (pieceBoard[coord1][coord2].test(0) && (pieceBoard[coord1][coord2].test(1) == friendlyPiece ||
                pieceBoard[coord1 + directionX][coord2 + DirectionY].test(0))))
            {
                return false;
            }
            else if (pieceBoard[coord1][coord2].test(0) && pieceBoard[coord1][coord2].test(1) != friendlyPiece &&
                    !pieceBoard[coord1 + directionX][coord2 + DirectionY].test(0))
            {
                return true;
            }
        }
        return false;
    }
public:
    pair<char, char> Capture(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> board[8][8])
    {
        char direction1 = fromPosition.first > toPosition.first ? -1 : 1;
        char direction2 = fromPosition.second > toPosition.second ? -1 : 1;
        if (abs(fromPosition.first - toPosition.first) != abs(fromPosition.second - toPosition.second))
        {
            return invalidMove;
        }
        if (!board[fromPosition.first][fromPosition.second].test(2))
        {
            return CaptureWithPiece(fromPosition, toPosition, board, direction1, direction2);
        }
        else
        {
            return CaptureWithDame(fromPosition, toPosition, board, direction1, direction2);
        }
    }

    pair<char, char> CaptureWithPiece(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> board[8][8], char direction1, char direction2)
    {
        if (abs(fromPosition.first - toPosition.first) == 2 && PieceCaptureCheck(direction1, direction2, board, fromPosition))
        {
            return make_pair(fromPosition.first + direction1, fromPosition.second + direction2);
        }
        else
        {
            return invalidMove;
        }
    }

    pair<char, char> CaptureWithDame(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> board[8][8], char direction1, char direction2)
    {
        if (board[toPosition.first][toPosition.second].test(0))
        {
            return invalidMove;
        }

        pair<char, char> result = invalidMove;
        bitset<3> capture, to;
        for (char i = 1; i < abs(fromPosition.first - toPosition.first); i++)
        {
            capture = board[fromPosition.first + direction1 * i][fromPosition.second + direction2 * i];
            to = board[fromPosition.first + direction1 * (i + 1)][fromPosition.second + direction2 * (i + 1)];

            if (capture.test(0) && ((capture.test(1) == friendlyPiece || to.test(0)) || (capture.test(1) != friendlyPiece && result != invalidMove)))
            {
                return invalidMove;
            }
            else if (capture.test(0) && capture.test(1) != friendlyPiece && !to.test(0) && result == invalidMove)
            {
                result = make_pair(fromPosition.first + direction1 * i, fromPosition.second + direction2 * i);
            }
        }
        return result;
    }

    bool CheckForCapture(bitset<3> pieceBoard[8][8])
    {
        for (pair<char, char> Piece : pieceCoordinates)
        {
            if (CheckForSpecifiedCapture(pieceBoard, Piece))
            {
                return true;
            }
        }
        for (pair<char, char> Dame : dameCoordinates)
        {
            if (CheckForSpecifiedCapture(pieceBoard, Dame))
            {
                return true;
            }
        }
        return false;
    }

    bool CheckForSpecifiedCapture(bitset<3> pieceBoard[8][8], pair<char, char> Piece)
    {
        if (!pieceBoard[Piece.first][Piece.second].test(2))
        {
            return ((Piece.first < lastBoardIndex - 1 && Piece.second < lastBoardIndex - 1 && PieceCaptureCheck(+1, +1, pieceBoard, Piece)) ||
                    (Piece.first > 1                  && Piece.second > 1                  && PieceCaptureCheck(-1, -1, pieceBoard, Piece)) ||
                    (Piece.first > 1                  && Piece.second < lastBoardIndex - 1 && PieceCaptureCheck(-1, +1, pieceBoard, Piece)) ||
                    (Piece.first < lastBoardIndex - 1 && Piece.second > 1                  && PieceCaptureCheck(+1, -1, pieceBoard, Piece)));
        }
        else
        {
            return  (DameCaptureCheck(+1, +1, pieceBoard, Piece)) ||
                    (DameCaptureCheck(-1, -1, pieceBoard, Piece)) ||
                    (DameCaptureCheck(-1, +1, pieceBoard, Piece)) ||
                    (DameCaptureCheck(+1, -1, pieceBoard, Piece));
        }
    }
};