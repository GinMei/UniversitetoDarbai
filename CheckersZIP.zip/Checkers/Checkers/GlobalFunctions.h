#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include <thread>
#include <chrono>
constexpr auto del_line = "\33[2K\r";
constexpr auto prev_line = "\033[A\r";

using namespace std;

const char boardPosition = 2;

void Wait(char seconds);
void GoTo(short line, short column);
void Error(string text);
void Comment(string text);
void ClearLines(short amount);
void playersMove(bool blackMove, pair<char, char>& fromPosition, pair<char, char>& ToPosition);
void DisplayVictor(bool victor);
void GoToBoardCoordinates(pair<char, char> position);
bool GetMoveInput(string& input);
pair<char, char> NumToCoordinates(char number);