#pragma once
#include "GlobalFunctions.h"
#include <bitset>
#include <vector>

using namespace std;

class PlayerBase
{
protected:
    bool friendlyPiece;
    wstring piece;
    wstring dame; 
    wstring space;
    vector <pair<char, char>> pieceCoordinates;
    vector <pair<char, char>> dameCoordinates;
public:
    bool PiecesLeft()
    {
        return !(pieceCoordinates.empty() && dameCoordinates.empty());
    }

    bool CanItMoveThere(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> pieceBoard[8][8])
    {
        bitset<3> from = pieceBoard[fromPosition.first][fromPosition.second],
                    to = pieceBoard[toPosition.first][toPosition.second];

        if (abs(fromPosition.first - toPosition.first) != abs(fromPosition.second - toPosition.second) || 
            !from.test(0) || from.test(1) != friendlyPiece || to.test(0))
        {
            return false;
        }
        else if (!from.test(2)) //move piece
        {
            return PieceDirectionCheck(fromPosition, toPosition);
        }
        else //move dame
        {
            char directionX = (fromPosition.first < toPosition.first) ? 1 : -1;
            char directionY = (fromPosition.second < toPosition.second) ? 1 : -1;
            return DameMoveCheck(fromPosition, toPosition, pieceBoard, directionX, directionY);
        }
        return false;
    }

    bool DameMoveCheck(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> pieceBoard[8][8], char directionX, char directionY)
    {
        for (char i = 1; i < abs(toPosition.first - fromPosition.first); i++)
        {
            if (pieceBoard[fromPosition.first + i * directionX][fromPosition.second + i * directionY].test(0))
            {
                return false;
            }
        }
        return true;
    }

    void MovePiece(pair<char, char> fromPosition, pair<char, char> toPosition, bitset<3> pieceBoard[8][8])
    {
        AddPiece(toPosition, pieceBoard[fromPosition.first][fromPosition.second].test(2), pieceBoard[toPosition.first][toPosition.second]);
        ErasePiece(fromPosition, pieceBoard[fromPosition.first][fromPosition.second]);
    }

    void PieceToOutput(pair<char, char> position, bool isItPiece) const
    {
        GoToBoardCoordinates(position);
        if (isItPiece)
        {
            wcout << piece;
        }
        else
        {
            wcout << dame;
        }
    }

    void ErasePiece(pair<char, char> position, bitset<3>& piece)
    {
        GoToBoardCoordinates(position);
        wcout << space;
        if (piece.test(2))
        {
            ErasePieceType(position, pieceCoordinates, piece);
        }
        else
        {
            ErasePieceType(position, dameCoordinates, piece);
        }
        piece.reset();
    }

    void ErasePieceType(pair<char, char> position, vector<pair<char, char>> pieceCoordinates, bitset<3>& piece)
    {
        for (char i = 0; i < (char)pieceCoordinates.size(); i++)
        {
            if (pieceCoordinates[i] == position)
            {
                pieceCoordinates.erase(pieceCoordinates.begin() + i);
                return;
            }
        }
    }

    virtual void AddPiece(pair<char, char> position, bool isItDame, bitset<3>& piece) {}

    virtual bool PieceDirectionCheck(pair<char, char> fromPosition, pair<char, char> toPosition)
    {
        return true;
    }
};