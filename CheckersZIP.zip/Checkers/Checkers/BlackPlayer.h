﻿#pragma once
#include "Player.h"
#include "GlobalFunctions.h"

using namespace std;
class BlackPlayer : public Player
{
private:
    bool PieceDirectionCheck(pair<char, char> fromPosition, pair<char, char> toPosition) override
    {
        return (fromPosition.first + 1 == toPosition.first);
    }
public:
    BlackPlayer() { }

    BlackPlayer(bool colorRed)
    {
        friendlyPiece = true;
        if (colorRed) //if white/red board
        {
            piece = L"\033[41;30m●\033[0;0m";
            dame = L"\033[41;30m◯\033[0;0m";
            space = L"\033[41;30m \033[0;0m";
        }
        else //white/black board
        {
            piece = L"\033[0;31m●\033[0;0m";
            dame = L"\033[0;31m◯\033[0;0m";
            space = L"\033[0;31m \033[0;0m";
        }
    }

    void AddPiece(pair<char, char> position, bool isItDame, bitset<3>& piece) override
    {
        if ((position.first + position.second) % 2 == 1)
        {
            piece.set();
            if (isItDame || position.first == lastBoardIndex)
            {
                dameCoordinates.push_back(position);
            }
            else
            {
                piece.reset(2);
                pieceCoordinates.push_back(position);
            }
        }
        PieceToOutput(position, (!isItDame && position.first != 7));
    }
};
