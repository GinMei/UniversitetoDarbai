#include "pch.h"
#include "CppUnitTest.h"
#include "../Checkers/PlayerBase.h"
#include "../Checkers/PlayerBase.cpp"
#include "../Checkers/Player.h"
#include "../Checkers/Player.cpp"
#include "../Checkers/BlackPlayer.h"
#include "../Checkers/BlackPlayer.cpp"
#include "../Checkers/WhitePlayer.h"
#include "../Checkers/WhitePlayer.cpp"
#include "../Checkers/GlobalFunctions.h"
#include "../Checkers/GlobalFunctions.cpp"
#include "../Checkers/Board.h"
#include "../Checkers/Board.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTests
{
	TEST_CLASS(UnitTests)
	{
	public:

		TEST_METHOD(DameCaptureCheck_CantCapture2InARow)
		{
			BlackPlayer player;
			bitset<3> pieceBoard[8][8];
			pieceBoard[3][0].set();
			pieceBoard[2][1].set(0);
			pieceBoard[1][2].set(0);
			pair<char, char> Piece = { 3,0 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsFalse(value, L"captured when there were 2 in a row");
		}
		TEST_METHOD(DameCaptureCheck_CantCaptureToWall)
		{
			BlackPlayer player;
			bitset<3> pieceBoard[8][8];
			pieceBoard[3][0].set(0);
			pieceBoard[2][1].set();
			pair<char, char> Piece = { 2,1 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsFalse(value, L"captured when there was a wall");
		}
		TEST_METHOD(DameCaptureCheck_CanCapture1)
		{
			BlackPlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[3][0].set();
			pieceBoard[2][1].set(0);
			pair<char, char> Piece = { 3,0 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsTrue(value, L"capture fail");
		}
		TEST_METHOD(DameCaptureCheck_CanCapture2)
		{
			BlackPlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[4][1].set();
			pieceBoard[3][2].set(0);
			pair<char, char> Piece = { 4,1 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsTrue(value, L"capture fail");
		}
		TEST_METHOD(DameCaptureCheck_CanCapture3)
		{
			BlackPlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[7][0].set();
			pieceBoard[1][6].set(0);
			pair<char, char> Piece = { 7,0 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsTrue(value, L"capture fail across main diagonal");
		}
		TEST_METHOD(DameCaptureCheck_CanCapture4)
		{
			BlackPlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[0][1].set();
			pieceBoard[5][6].set(0);
			pair<char, char> Piece = { 0,1 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsTrue(value, L"capture fail on diagonal");
		}
		TEST_METHOD(PieceCaptureCheck_CanCapture1)
		{
			WhitePlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[3][0].set(0);
			pieceBoard[2][1].set();
			pair<char, char> Piece = { 3,0 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsTrue(value, L"capture fail");
		}
		TEST_METHOD(PieceCaptureCheck_CanCapture2)
		{
			WhitePlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[4][1].set(0);
			pieceBoard[3][2].set();
			pair<char, char> Piece = { 4,1 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsTrue(value, L"capture fail");
		}
		TEST_METHOD(PieceCaptureCheck_CantCaptureToWall)
		{
			WhitePlayer player(true);
			bitset<3> pieceBoard[8][8];
			pieceBoard[5][0].set();
			pieceBoard[1][4].set(0);
			pair<char, char> Piece = { 5,0 };
			bool value = player.CheckForSpecifiedCapture(pieceBoard, Piece);
			Assert::IsFalse(value, L"captured to wall");
		}
	};
}